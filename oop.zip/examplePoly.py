str1 = "Привет " + "друг"
int1 = 2 + 6
float1 = 3.41 + 2.62
list = []
list.append(str1)
list.append(int1)
list.append(float1)

def test():
    print(str1)
    print(int1)
    print(float1)
    print(list)

if __name__ == "__main__":
    test()